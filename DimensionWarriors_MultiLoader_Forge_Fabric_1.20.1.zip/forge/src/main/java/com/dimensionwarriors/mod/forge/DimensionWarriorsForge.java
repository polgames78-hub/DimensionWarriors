package com.dimensionwarriors.mod.forge;

import com.dimensionwarriors.mod.DimensionWarriorsCommon;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Minecraft Forge 1.20.1 Giriş Noktası
 */
@Mod(DimensionWarriorsCommon.MOD_ID)
public class DimensionWarriorsForge {
    public DimensionWarriorsForge() {
        // Ortak mod başlatıcısını çağır
        DimensionWarriorsCommon.init();

        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
    }

    private void setup(final FMLCommonSetupEvent event) {
        DimensionWarriorsCommon.LOGGER.info("[Boyut Savaşçıları] Forge 1.20.1 Mod Başarıyla Yüklendi!");
    }
}
