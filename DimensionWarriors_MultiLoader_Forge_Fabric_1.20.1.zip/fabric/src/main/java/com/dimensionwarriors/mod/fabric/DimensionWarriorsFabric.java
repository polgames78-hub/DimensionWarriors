package com.dimensionwarriors.mod.fabric;

import com.dimensionwarriors.mod.DimensionWarriorsCommon;
import net.fabricmc.api.ModInitializer;

/**
 * Minecraft Fabric 1.20.1 Giriş Noktası
 */
public class DimensionWarriorsFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        // Ortak mod başlatıcısını çağır
        DimensionWarriorsCommon.init();
        DimensionWarriorsCommon.LOGGER.info("[Boyut Savaşçıları] Fabric 1.20.1 Mod Başarıyla Yüklendi!");
    }
}
