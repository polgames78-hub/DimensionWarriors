# BOYUT SAVAŞÇILARI (Dimension Warriors) - Minecraft 1.20.1 Multi-Loader (Forge & Fabric) Mod Projesi

Bu proje, **Architectury API** ve **Gradle Multi-Project** mimarisi kullanılarak hem **Forge** hem de **Fabric** mod yükleyicilerini aynı ortak kod tabanından destekleyecek şekilde yapılandırılmıştır.

---

## 📁 Proje Klasör Mimarisi (Architectury Structure)
```text
dimensionwarriors/
├── common/                  # Forge ve Fabric'in ORTAK kullandığı Java kodları ve modeller
│   ├── src/main/java/com/dimensionwarriors/mod/
│   │   ├── DimensionWarriorsCommon.java
│   │   └── item/DimensionalSlicerItem.java
│   └── src/main/resources/assets/dimensionwarriors/
├── forge/                   # Minecraft Forge 1.20.1 Özel Sınıfları ve META-INF/mods.toml
│   ├── src/main/java/com/dimensionwarriors/mod/forge/DimensionWarriorsForge.java
│   └── src/main/resources/META-INF/mods.toml
├── fabric/                  # Minecraft Fabric 1.20.1 Özel Sınıfları ve fabric.mod.json
│   ├── src/main/java/com/dimensionwarriors/mod/fabric/DimensionWarriorsFabric.java
│   └── src/main/resources/fabric.mod.json
├── settings.gradle          # Multi-project bağlayıcı (common, forge, fabric)
├── gradle.properties        # Sürüm ve bağımlılık sabitleri (1.20.1, Forge 47.2.0, Fabric Loader 0.15.7)
└── build.gradle             # Ana Gradle derleme senaryosu
```

---

## 🚀 OTOMATİK .JAR OLUŞTURMA & DERLEME ADIMLARI

### Gereksinimler:
- Java Development Kit **(JDK 17)** kurulu olmalıdır.
- IntelliJ IDEA veya Eclipse Java IDE (Tavsiye edilen: IntelliJ IDEA).

### 1️⃣ Tek Komutla Hem Forge Hem Fabric .JAR Üretimi:
Terminal / Komut Satırında projenin ana dizinindeyken aşağıdaki tek komutu çalıştırın:

```bash
# Linux / macOS:
./gradlew build

# Windows PowerShell / CMD:
gradlew.bat build
```

---

## 📦 DERLENEN .JAR ÇIKTILARI (Build Output)
Derleme başarıyla tamamlandığında hazır .jar dosyaları aşağıdaki yollarda oluşacaktır:

1. **FORGE .JAR ÇIKTISI:**
   `forge/build/libs/dimensionwarriors-forge-1.20.1-1.0.0.jar`
   *(Minecraft Forge 1.20.1 - 47.x.x yükleyicisi ve mods/ klasörü için)*

2. **FABRIC .JAR ÇIKTISI:**
   `fabric/build/libs/dimensionwarriors-fabric-1.20.1-1.0.0.jar`
   *(Minecraft Fabric 1.20.1 + Fabric API yükleyicisi ve mods/ klasörü için)*

---

## ⚔️ MOD İÇERİĞİ
- **3 Efsanevi Silah:** Boyut Bıçaklayan Kılıç (Dimensional Slicer), Kaos Yıldırım Asası, Karanlık Madde Çekiçi.
- **2 Zindan:** Çöküntü Tapınağı & Kozmik Yıldız Kalesi.
- **1 Boss:** 2-Fazlı Boyut Hükümdarı: Xal'korath.
