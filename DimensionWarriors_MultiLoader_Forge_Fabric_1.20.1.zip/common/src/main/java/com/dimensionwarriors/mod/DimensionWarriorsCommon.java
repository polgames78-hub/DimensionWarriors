package com.dimensionwarriors.mod;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common Mod Giriş Noktası
 * Hem Forge hem de Fabric mod yükleyicilerinde ortak çalışan ana başlatıcı.
 */
public class DimensionWarriorsCommon {
    public static final String MOD_ID = "dimensionwarriors";
    public static final Logger LOGGER = LoggerFactory.getLogger("DimensionWarriors");

    public static void init() {
        LOGGER.info("[Boyut Savaşçıları] Multi-Loader Mod Başlatılıyor! (Minecraft 1.20.1 Common Init)");
        // Ortak kayıt sistemleri (Items, Blocks, Sounds, Particles)
    }
}
