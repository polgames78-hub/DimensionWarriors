package com.dimensionwarriors.mod.item;

import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class DimensionalSlicerItem extends SwordItem {
    private static final int COOLDOWN_TICKS = 240; // 12 Saniye
    private static final double DASH_POWER = 2.2D;
    private static final double AOE_RADIUS = 3.5D;
    private static final float ABILITY_DAMAGE = 15.0F;

    public DimensionalSlicerItem(Properties properties) {
        super(Tiers.NETHERITE, 8, -2.4F, properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack itemstack = player.getItemInHand(hand);

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(itemstack);
        }

        if (!level.isClientSide()) {
            ServerLevel serverLevel = (ServerLevel) level;

            Vec3 lookVec = player.getLookAngle();
            Vec3 startPos = player.position();

            player.setDeltaMovement(lookVec.x * DASH_POWER, 0.4D, lookVec.z * DASH_POWER);
            player.hurtMarked = true;

            serverLevel.sendParticles(ParticleTypes.PORTAL, startPos.x, startPos.y + 1.0, startPos.z, 50, 0.5, 1.0, 0.5, 0.2);
            serverLevel.sendParticles(ParticleTypes.DRAGON_BREATH, startPos.x, startPos.y + 1.0, startPos.z, 35, 0.8, 0.8, 0.8, 0.05);

            Vec3 targetPos = startPos.add(lookVec.scale(8.0D));
            AABB searchBox = new AABB(startPos, targetPos).inflate(AOE_RADIUS);

            List<LivingEntity> nearbyEntities = level.getEntitiesOfClass(LivingEntity.class, searchBox, 
                e -> e != player && e.isAlive() && !e.isAlliedTo(player));

            for (LivingEntity target : nearbyEntities) {
                target.hurt(level.damageSources().playerAttack(player), ABILITY_DAMAGE);
                target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0));
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
                serverLevel.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + 1.0, target.getZ(), 20, 0.3, 0.5, 0.3, 0.1);
            }

            level.playSound(null, player.getX(), player.getY(), player.getZ(), 
                SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.2F, 0.8F);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), 
                SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 0.6F, 1.5F);

            player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
            itemstack.hurtAndBreak(2, player, (p) -> p.broadcastBreakEvent(hand));
        }

        return InteractionResultHolder.sidedSuccess(itemstack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§5§l[EFSANEVİ BOYUT SİLAHI]"));
        tooltip.add(Component.literal("§7Sağ Tık: §dBoyut Yarığı (Dimensional Dash)"));
        tooltip.add(Component.literal("§7  • 8 Blok ileri ışınlanırsın."));
        tooltip.add(Component.literal("§7  • Yolundaki yaratıklara §c15 Hasar §7verir."));
        tooltip.add(Component.literal("§8Bekleme Süresi: §e12 Saniye"));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
